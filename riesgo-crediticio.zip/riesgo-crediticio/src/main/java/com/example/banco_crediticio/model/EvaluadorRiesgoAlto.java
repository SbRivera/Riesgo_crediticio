package com.example.banco_crediticio.model;

import jakarta.persistence.Entity;

@Entity
public class EvaluadorRiesgoAlto extends EvaluadorRiesgo {
    @Override
    public boolean aplica(Cliente cliente) {
        return cliente.getPuntajeCrediticio() < 60;
    }

    @Override
    public ResultadoEvaluacion evaluar(Cliente cliente) {
        int puntajeFinal = calcularPuntajeFinal(cliente);
        return ResultadoEvaluacion.builder()
                .nivelRiesgo(determinarNivelRiesgo(puntajeFinal))
                .aprobado(false)
                .puntajeFinal(puntajeFinal)
                .mensaje("Cliente con alto riesgo. Crédito denegado.")
                .tasaInteres(0.0)
                .plazoAprobado(0)
                .build();
    }
}

