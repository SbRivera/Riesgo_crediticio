package com.example.banco_crediticio.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class HistorialEvaluacionDTO {
    private Long id;
    private String clienteNombre;
    private String tipoCliente;
    private double montoSolicitado;
    private int plazoEnMeses;
    private String nivelRiesgo;
    private boolean aprobado;
    private LocalDateTime fechaConsulta;
}
