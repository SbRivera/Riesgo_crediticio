package com.example.banco_crediticio.dto;

import lombok.Data;

@Data
public class EvaluacionResponseDTO {
    private boolean aprobado;
    private String nivelRiesgo;
    private int puntajeFinal;
    private String mensaje;
    private double tasaInteres;
    private int plazoAprobado;
}

