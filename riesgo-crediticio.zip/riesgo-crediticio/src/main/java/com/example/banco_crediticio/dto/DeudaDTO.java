package com.example.banco_crediticio.dto;

import lombok.Data;

@Data
public class DeudaDTO {
    private double monto;
    private int plazoMeses;
}

