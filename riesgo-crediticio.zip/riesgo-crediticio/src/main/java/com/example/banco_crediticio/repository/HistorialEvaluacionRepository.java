package com.example.banco_crediticio.repository;

import com.example.banco_crediticio.model.HistorialEvaluacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistorialEvaluacionRepository extends JpaRepository<HistorialEvaluacion, Long> {
    List<HistorialEvaluacion> findByClienteId(Long clienteId);
}

