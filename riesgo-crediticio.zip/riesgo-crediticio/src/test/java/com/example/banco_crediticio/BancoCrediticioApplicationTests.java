package com.example.banco_crediticio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancoCrediticioApplicationTests {

	@Test
	void contextLoads() {
	}

}
